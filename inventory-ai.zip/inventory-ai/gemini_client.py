import requests

GEMINI_API_KEY = "AIzaSyBZekWOsIWEkQ8bj1SvgcJn9exrykqIn5M"
GEMINI_API_URL = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key={GEMINI_API_KEY}"

def query_gemini(prompt: str) -> str:
    headers = {"Content-Type": "application/json"}
    body = {
        "contents": [
            {
                "parts": [{"text": prompt}]
            }
        ]
    }
    response = requests.post(GEMINI_API_URL, headers=headers, json=body)
    result = response.json()
    try:
        return result['candidates'][0]['content']['parts'][0]['text']
    except:
        return "Error in Gemini response."
