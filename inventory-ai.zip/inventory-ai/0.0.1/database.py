import mysql.connector
from mysql.connector import pooling
import time
from typing import Optional, Dict, Any

class DatabaseManager:
    _instance = None
    _connection_pool = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._initialize_pool()
        return cls._instance

    @classmethod
    def _initialize_pool(cls):
        """Initialize the database connection pool"""
        try:
            cls._connection_pool = pooling.MySQLConnectionPool(
                pool_name="inventory_ai_pool",
                pool_size=5,
                pool_reset_session=True,
                host="localhost",
                user="root",
                password="",
                database="inventory_db",
                autocommit=True
            )
            print("✅ Database connection pool initialized successfully")
        except mysql.connector.Error as err:
            print(f"❌ Failed to initialize database pool: {err}")
            cls._connection_pool = None

    @classmethod
    def get_connection(cls, max_retries: int = 3, retry_delay: float = 1) -> mysql.connector.connection.MySQLConnection:
        """
        Get a database connection from the pool with retry mechanism
        Args:
            max_retries: Maximum number of connection attempts
            retry_delay: Delay between retries in seconds
        Returns:
            MySQLConnection: Active database connection
        Raises:
            RuntimeError: If connection cannot be established after retries
        """
        if cls._connection_pool is None:
            cls._initialize_pool()
            if cls._connection_pool is None:
                raise RuntimeError("Database connection pool not available")

        attempt = 0
        last_error = None

        while attempt < max_retries:
            try:
                connection = cls._connection_pool.get_connection()
                if connection.is_connected():
                    return connection
            except mysql.connector.Error as err:
                last_error = err
                attempt += 1
                print(f"⚠ Connection attempt {attempt} failed: {err}")
                if attempt < max_retries:
                    time.sleep(retry_delay)
                    # Reinitialize pool if connection failed
                    if "MySQL Connection not available" in str(err):
                        cls._initialize_pool()

        raise mysql.connector.Error(
            f"Failed to get database connection after {max_retries} attempts. Last error: {last_error}"
        )

    @classmethod
    def execute_query(
        cls,
        query: str,
        params: Optional[tuple] = None,
        fetch_all: bool = True
    ) -> Optional[list[Dict[str, Any]]]:
        """
        Execute a database query with automatic connection handling
        Args:
            query: SQL query string
            params: Parameters for the query
            fetch_all: Whether to fetch all results or just one
        Returns:
            List of dictionaries representing rows, or None if operation fails
        """
        connection = None
        cursor = None
        try:
            connection = cls.get_connection()
            cursor = connection.cursor(dictionary=True)

            cursor.execute(query, params or ())
            
            if query.strip().upper().startswith("SELECT"):
                return cursor.fetchall() if fetch_all else cursor.fetchone()
            else:
                connection.commit()
                if query.strip().upper().startswith("INSERT"):
                    return cursor.lastrowid
                return True

        except mysql.connector.Error as err:
            print(f"❌ Database error: {err}")
            if connection:
                connection.rollback()
            return None
        finally:
            if cursor:
                cursor.close()
            if connection:
                connection.close()

    @classmethod
    def health_check(cls) -> bool:
        """Check if database is reachable and pool is working"""
        try:
            conn = cls.get_connection()
            cursor = conn.cursor()
            cursor.execute("SELECT 1")
            cursor.close()
            conn.close()
            return True
        except Exception as e:
            print(f"❌ Database health check failed: {e}")
            return False

# Initialize the pool when module is imported
DatabaseManager.health_check()

# Legacy function for backward compatibility
def get_db_connection() -> mysql.connector.connection.MySQLConnection:
    """Legacy function to maintain compatibility with existing code"""
    return DatabaseManager.get_connection()
