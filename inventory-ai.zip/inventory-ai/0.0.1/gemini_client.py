import requests

GEMINI_API_KEY = "AIzaSyBZekWOsIWEkQ8bj1SvgcJn9exrykqIn5M"
GEMINI_API_URL = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key={GEMINI_API_KEY}"

def query_gemini(prompt: str, system_instruction: str = None) -> str:
    headers = {"Content-Type": "application/json"}
    contents = [{"parts": [{"text": prompt}]}]
    
    if system_instruction:
        contents.insert(0, {
            "parts": [{"text": system_instruction}],
            "role": "model"
        })
    
    body = {
        "contents": contents,
        "generationConfig": {
            "temperature": 0.2,
            "topP": 0.95,
            "maxOutputTokens": 100
        }
    }
    
    response = requests.post(GEMINI_API_URL, headers=headers, json=body)
    result = response.json()
    
    try:
        return result['candidates'][0]['content']['parts'][0]['text']
    except:
        return "Error in Gemini response."
