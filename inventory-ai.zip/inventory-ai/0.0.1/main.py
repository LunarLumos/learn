from fastapi import FastAPI, Request
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from database import get_db_connection
from gemini_client import query_gemini
import json

app = FastAPI()

app.mount("/static", StaticFiles(directory="static"), name="static")
templates = Jinja2Templates(directory="templates")

SYSTEM_INSTRUCTION = """
You are an advanced e-commerce product detection AI. Analyze user queries and respond in JSON format with:
{
    "type": "category"|"price"|"discount"|"material"|"all_products"|"all_categories",
    "value": "specific value if applicable",
    "category": "specific category if applicable",
    "min_price": number or null,
    "max_price": number or null,
    "discount_percent": number or null,
    "material": "string or null"
}

Examples:
1. "show me phones" → {"type":"category","value":"phones","category":"phones"}
2. "products under $50" → {"type":"price","max_price":50}
3. "discounted laptops" → {"type":"discount","category":"laptops","discount_percent":0}
4. "cotton t-shirts" → {"type":"material","material":"cotton","category":"t-shirts"}
5. "show all" → {"type":"all_products"}
6. "list categories" → {"type":"all_categories"}
"""

@app.get("/")
async def read_root(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})

@app.get("/api/suggest")
def suggest_products(prompt: str):
    # Get AI analysis of the prompt
    analysis = query_gemini(
        prompt,
        system_instruction=SYSTEM_INSTRUCTION
    )
    
    try:
        data = json.loads(analysis.strip().replace('```json', '').replace('```', ''))
    except:
        return {"message": "Sorry, I couldn't understand your request. Please try again."}
    
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    
    # Build query based on AI analysis
    query = "SELECT name, description, price, discount FROM products"
    conditions = []
    params = []
    
    if data.get("type") == "category" and data.get("category"):
        conditions.append("category = %s")
        params.append(data["category"])
    
    if data.get("type") == "material" and data.get("material"):
        conditions.append("(description LIKE %s OR name LIKE %s)")
        params.extend([f"%{data['material']}%", f"%{data['material']}%"])
    
    if data.get("min_price") is not None or data.get("max_price") is not None:
        min_p = data.get("min_price", 0)
        max_p = data.get("max_price", float('inf'))
        conditions.append("price BETWEEN %s AND %s")
        params.extend([min_p, max_p])
    
    if data.get("discount_percent") is not None:
        if data["discount_percent"] > 0:
            conditions.append("discount = %s")
            params.append(data["discount_percent"])
        else:
            conditions.append("discount > 0")
    
    if conditions:
        query += " WHERE " + " AND ".join(conditions)
    
    query += " LIMIT 20"
    
    cursor.execute(query, params)
    products = cursor.fetchall()
    conn.close()
    
    # Handle special cases
    if data.get("type") == "all_categories":
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT DISTINCT category FROM products")
        categories = [row[0] for row in cursor.fetchall()]
        conn.close()
        
        if categories:
            return {
                "type": "categories",
                "categories": categories,
                "message": f"Found {len(categories)} categories"
            }
        else:
            return {"message": "No categories found"}
    
    if not products:
        return {"message": f"No products found matching your criteria"}
    
    # Prepare response
    response = {
        "type": data["type"],
        "products": products,
        "count": len(products)
    }
    
    if data.get("category"):
        response["category"] = data["category"]
    if data.get("material"):
        response["material"] = data["material"]
    if data.get("min_price") is not None or data.get("max_price") is not None:
        response["price_range"] = {
            "min": data.get("min_price", 0),
            "max": data.get("max_price", "any")
        }
    if data.get("discount_percent") is not None:
        response["discount"] = data["discount_percent"] if data["discount_percent"] > 0 else "any"
    
    return response
