from fastapi import FastAPI, Request
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from database import get_db_connection
from gemini_client import query_gemini

app = FastAPI()

app.mount("/static", StaticFiles(directory="static"), name="static")
templates = Jinja2Templates(directory="templates")


MEANINGLESS_CATEGORIES = {"products", "product", "all", "categories", "catagories", "all products", "all categories"}

@app.get("/")
async def read_root(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})

@app.get("/api/suggest")
def suggest_products(prompt: str):
    initial_prompt = f"""
You are an AI assistant for an e-commerce site.

Given this user input:
\"\"\"{prompt}\"\"\"

Extract the product category the user is interested in.
Return only the category name, e.g., "t-shirts", "electronics", "clothing".
If the input is too generic or unclear, respond with "all" if user likely wants all products.
If user is asking about categories, respond with "categories".

No explanations or extra text.
"""
    category = query_gemini(initial_prompt).strip().lower()

    if category in MEANINGLESS_CATEGORIES:
        if category in {"categories", "catagories"}:
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute("SELECT DISTINCT category FROM products")
            all_categories = [row[0] for row in cursor.fetchall()]
            conn.close()
            if all_categories:
                return {
                    "category": "all categories",
                    "categories": all_categories
                }
            else:
                return {"message": "No categories found in the database."}

        elif category == "all":
            conn = get_db_connection()
            cursor = conn.cursor(dictionary=True)
            cursor.execute("SELECT name, description, price, discount FROM products LIMIT 20")
            products = cursor.fetchall()
            conn.close()
            if products:
                return {
                    "category": "all products",
                    "products": products
                }
            else:
                return {"message": "No products found in the database."}

        else:
            return {"message": f"Sorry, I couldn't understand '{prompt}'. Please specify a product category."}

    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    query = "SELECT name, description, price, discount FROM products WHERE category = %s LIMIT 10"
    cursor.execute(query, (category,))
    results = cursor.fetchall()

    if not results:
        fallback_prompt = f"""
In e-commerce, '{category}' might be a sub-category or uncommon category.

Provide its broader or general category name.
Return only one category name like "clothing", "electronics", "appliances", or return "none" if no broader category exists.
No explanations.
"""
        general_category = query_gemini(fallback_prompt).strip().lower()

        if general_category != category and general_category != "none":
            cursor.execute(query, (general_category,))
            results = cursor.fetchall()
            if results:
                conn.close()
                return {
                    "category": f"{category} (fallback: {general_category})",
                    "products": results
                }

    conn.close()

    if not results:
        return {"message": f"No products found for category '{category}'."}

    return {
        "category": category,
        "products": results
    }
